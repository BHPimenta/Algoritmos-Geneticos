
package projeto.ag.pkgfinal;
import java.util.Random;
/**
 *
 * @author Bruno
 */
public class ProjetoAGFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int k=10;
        int[] vet = new int[k];
        int cand=20;
        int[][] Candidatos = new int[cand][k];
        CriacaoMatrizPesos(10);
        System.out.println();
        VetBinario(vet, k);
        /*for(int i=0; i<k; i++){
            System.out.print(vet[i]);
        }*/
        PrimeiraColuna(Candidatos, cand);
                
        PrimeiraLinha(Candidatos,k, vet);
        
        ConstrucaoCromossomos(Candidatos, k, vet, cand);
        
        Imprime(Candidatos, k, cand);
    } 
    
    public static void CriacaoMatrizPesos(int k){
        Random gerador = new Random();
        int matriz[][] = new int[k][k];
        for(int i=0; i<k; i++){
            for(int j=i+1; j<k; j++){
                int x = gerador.nextInt(100)+1;
                matriz[i][j] = x;
                matriz[j][i] = x;
            }
        }
        for(int i=0; i<k; i++){
            for(int j=0; j<k; j++){
                System.out.print(matriz[i][j]+" " );
            }
            System.out.println();
        }
      
    }
    
    public static void VetBinario(int[] vet, int k){    
        for(int i=0; i<k; i++){
            for(int j=0; j<k; j++){
                if(j==0){//ponto de partido de todos os cromossos é em 0
                    vet[j]=1;
                }
                else{
                    vet[j]=0;
                }   
            }
        }
    }
    public static void PrimeiraColuna(int[][] Candidatos, int cand){
        for(int i=0;i<cand;i++){
            Candidatos[i][0] = 0; 
        }
    }
    public static void PrimeiraLinha(int[][] Candidatos, int k, int[]vet){
        int aux=1, j=1;
        while(aux<=k-1){
            int valor = new Random().nextInt(k-1);
            valor=valor+1;
            if(vet[valor]==0){
                Candidatos[0][j]=valor;
                vet[valor]=1;
                aux++;
                j++;
            }
        }
    }
    
    public static void ConstrucaoCromossomos(int[][] Candidatos, int k, int[] vet, int cand){
        int aux;
        for(int i=1;i<cand;i++){
            VetBinario(vet, k);
            for(int j=1;j<k;j++){
                aux=1;
                while(aux==1){
                    if(i+1<=j){
                    Candidatos[i][j]=Candidatos[i-1][j-1];
                    vet[Candidatos[i][j]]=1;
                    aux=0;
                    }
                    else{
                        int valor = new Random().nextInt(k-1);
                        valor=valor+1;
                        if(vet[valor]==0){
                        Candidatos[i][j]=valor;
                        vet[valor]=1;
                        aux=0;
                        }  
                    }    
                }
            }   
        }    
    }
    
    public static void Imprime(int[][] Candidatos, int k, int cand){
        for(int i=0; i<cand;i++){
            for(int j=0; j<k; j++){
                System.out.print(Candidatos[i][j]+"\t");
            }
            System.out.print("\n");
        }
    }
}
